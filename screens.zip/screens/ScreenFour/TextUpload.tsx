/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {Text, TextInput, View} from 'react-native';
import theme from '../../styles/theme';
import { GestureHandlerRootView, ScrollView } from 'react-native-gesture-handler';

const TextUpload = () => {
  return (
    <View style={{padding: 20}}>
      <TextInput
        style={{
          height: 200,
          width: '100%',
          borderRadius: 10,
          borderWidth: 3,
          borderColor: theme.color.grey,
          color: theme.color.black,
          textAlign: 'right',
          textAlignVertical: 'bottom',
          fontSize: 20,
          marginVertical: 20,
        }}
        editable={false}
        value="cat in jar"
      />
      <View
        style={{
          height: 40,
          width: '100%',
          backgroundColor: theme.color.blue,
          alignItems: 'center',
          justifyContent: 'center',
          borderRadius: 6,
        }}>
        <Text style={{color: theme.color.white, fontSize: 16}}>
          Tap to Upload
        </Text>
      </View>
      <GestureHandlerRootView>
        <ScrollView>
          
        </ScrollView>
      </GestureHandlerRootView>
    </View>
  );
};

export default TextUpload;
