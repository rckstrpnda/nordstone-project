import React from 'react';
import {Image, Text, View} from 'react-native';
import theme from '../../styles/theme';
import {ScrollView, GestureHandlerRootView} from 'react-native-gesture-handler';

const ImageUpload = () => {
  return (
    <GestureHandlerRootView style={{padding: 20, alignItems: 'center'}}>
      <ScrollView>
        <Text style={{color: theme.color.black, fontSize: 24}}>
          Upload Image
        </Text>
        <View
          style={{
            width: 200,
            height: 300,
            backgroundColor: theme.color.grey,
            borderRadius: 10,
            alignItems: 'center',
            justifyContent: 'center',
            marginBottom: 20,
          }}>
          <Image
            source={require('../../styles/png/addphoto.png')}
            style={{height: 37, width: 41, resizeMode: 'contain'}}
          />

          <Text style={{color: theme.color.black, fontSize: 24}}>
            Tap to Select Image
          </Text>
        </View>
        <Text style={{color: theme.color.black, fontSize: 24}}>
          Uploaded Image
        </Text>
        <View
          style={{
            width: 200,
            height: 400,
            backgroundColor: theme.color.grey,
            borderRadius: 10,
            alignItems: 'center',
            justifyContent: 'center',
            marginBottom: 20,
          }}>
          <Image
            source={require('../../styles/png/addphoto.png')}
            style={{height: 37, width: 41, resizeMode: 'contain'}}
          />
        </View>
      </ScrollView>
    </GestureHandlerRootView>
  );
};

export default ImageUpload;
