/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {TouchableOpacity, View} from 'react-native';
import theme from '../../styles/theme';


const Notification = () => {
  return (
    <View
      style={{
        padding: 16,
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: '50%',
      }}>
      <TouchableOpacity
        style={{
          height: 200,
          width: 200,
          backgroundColor: theme.color.red,
          borderRadius: 100,
        }}
      />
    </View>
  );
};

export default Notification;
