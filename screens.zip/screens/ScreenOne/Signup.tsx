import React from 'react';
import {Text, View} from 'react-native';
import theme from '../../styles/theme';

const Signup = () => {
  console.log(theme.color.black);
  return (
    <View>
      <Text style={{color: theme.color.black}}>ho</Text>
    </View>
  );
};

export default Signup;
